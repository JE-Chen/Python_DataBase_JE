from JEDatabase.Core.SQLiteCore import SQLiteCore
